# Welcome to CMSK 0152 - Introduction to JavaScript. 

In this course, you will be introduced to JavaScript. You will learn how to create functions using basic syntax, arrays, and objects. Moreover, you will explore how to program in JavaScript, debug JavaScript, and integrate JavaScript code into HTML pages to make them more dynamic and interactive.

There are five modules in the course:
* Introduction to JavaScript
* JavaScript Variables, Data Types, and Functions
* JavaScript Objects, Arrays, Operators, and Conditions
* JavaScript Loops, Promises, and Async
* JavaScript Exercise-Based Practice
